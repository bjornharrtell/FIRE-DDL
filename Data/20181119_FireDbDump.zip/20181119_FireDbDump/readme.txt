Der er kun medtaget tabeller som indeholder data
Data er begr�nset til de 100 senest tilkomne punkter
Data er dannet p� baggrund af DDL af 2018-11-16. P� grund af syntaksfejl i DDL er ikke alle constraints implementeret. Data i dette dump er derfor heller ikke valideret i forhold til alle regler/constraints.

