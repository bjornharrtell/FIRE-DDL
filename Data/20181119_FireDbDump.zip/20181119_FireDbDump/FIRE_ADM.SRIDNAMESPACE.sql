SET DEFINE OFF;
--SQL Statement which produced this data:
--
--  SELECT * FROM FIRE_ADM.SRIDNAMESPACE;
--
Insert into SRIDNAMESPACE
   (OBJECTID, BESKRIVELSE, NAMESPACE)
 Values
   (8, 'Ingen beskrivelse', 'DK');
Insert into SRIDNAMESPACE
   (OBJECTID, BESKRIVELSE, NAMESPACE)
 Values
   (9, 'Ingen beskrivelse', 'EPSG');
Insert into SRIDNAMESPACE
   (OBJECTID, BESKRIVELSE, NAMESPACE)
 Values
   (10, 'Ingen beskrivelse', 'FO');
Insert into SRIDNAMESPACE
   (OBJECTID, BESKRIVELSE, NAMESPACE)
 Values
   (11, 'Ingen beskrivelse', 'GL');
Insert into SRIDNAMESPACE
   (OBJECTID, BESKRIVELSE, NAMESPACE)
 Values
   (12, 'Ingen beskrivelse', 'LOC');
Insert into SRIDNAMESPACE
   (OBJECTID, BESKRIVELSE, NAMESPACE)
 Values
   (13, 'Ingen beskrivelse', 'NKG');
Insert into SRIDNAMESPACE
   (OBJECTID, BESKRIVELSE, NAMESPACE)
 Values
   (14, 'Ingen beskrivelse', 'TS');
COMMIT;
