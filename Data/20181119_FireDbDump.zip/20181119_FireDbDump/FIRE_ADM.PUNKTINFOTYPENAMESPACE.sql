SET DEFINE OFF;
--SQL Statement which produced this data:
--
--  SELECT * FROM FIRE_ADM.PUNKTINFOTYPENAMESPACE;
--
Insert into PUNKTINFOTYPENAMESPACE
   (OBJECTID, BESKRIVELSE, NAMESPACE)
 Values
   (1, 'Ingen beskrivelse', 'AFM');
Insert into PUNKTINFOTYPENAMESPACE
   (OBJECTID, BESKRIVELSE, NAMESPACE)
 Values
   (2, 'Ingen beskrivelse', 'ATTR');
Insert into PUNKTINFOTYPENAMESPACE
   (OBJECTID, BESKRIVELSE, NAMESPACE)
 Values
   (3, 'Ingen beskrivelse', 'IDENT');
Insert into PUNKTINFOTYPENAMESPACE
   (OBJECTID, BESKRIVELSE, NAMESPACE)
 Values
   (4, 'Ingen beskrivelse', 'NET');
Insert into PUNKTINFOTYPENAMESPACE
   (OBJECTID, BESKRIVELSE, NAMESPACE)
 Values
   (5, 'Ingen beskrivelse', 'PS');
Insert into PUNKTINFOTYPENAMESPACE
   (OBJECTID, BESKRIVELSE, NAMESPACE)
 Values
   (6, 'Ingen beskrivelse', 'REGION');
Insert into PUNKTINFOTYPENAMESPACE
   (OBJECTID, BESKRIVELSE, NAMESPACE)
 Values
   (7, 'Ingen beskrivelse', 'SKITSE');
COMMIT;
