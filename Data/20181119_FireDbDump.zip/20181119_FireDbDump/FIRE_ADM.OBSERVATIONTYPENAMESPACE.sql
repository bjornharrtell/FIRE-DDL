SET DEFINE OFF;
--SQL Statement which produced this data:
--
--  SELECT * FROM FIRE_ADM.OBSERVATIONTYPENAMESPACE;
--
Insert into OBSERVATIONTYPENAMESPACE
   (OBJECTID, BESKRIVELSE, NAMESPACE)
 Values
   (3, 'Ingen beskrivelse', 'OBS');
COMMIT;
